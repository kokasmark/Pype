# Pype

![logo](https://github.com/kokasmark/Pype/blob/main/banner.png?raw=true)

**Fast** and **Simple** GUI framework for Python

Render **Python** computed values and interact them via **HTML** in a webview application

Good for fast visualization or **lightweight applications**
